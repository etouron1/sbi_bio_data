import numpy as np
from sklearn.metrics import euclidean_distances
from itertools import combinations

def get_num_beads_and_start(chr_seq, sep):

    """ return a dict {chr : nb of beads}, a dict {chr : number of the start bead}, the total number of beads for all chr"""

    chr_bead = {}    # number of beads for each chromosome
    nbead = 0		# total number of beads for all chromosomes
    bead_start = {}  # bead label starts of a chr

    for i in chr_seq.keys(): 
        n = int(chr_seq[i] // sep) + int(chr_seq[i] % sep!=0)
        chr_bead[i] = n # number of beads for chromosome i
        
        nbead = nbead + n # total number of beads for all chromosmes
        bead_start[i] = nbead - n # the start bead for chr i
    return chr_bead, bead_start, nbead

def get_contact_matrix_inter_chr(chr_seq, sep, config_3D_pop, chr_1, chr_2):
    """ create the contact matrix between two chromosomes from a population of 3D DNA structures"""

    thresh = 45 #nm each bead at distance <= thresh nm are in contact
    
    
    num_chr_num_bead, chr_bead_start, nbead = get_num_beads_and_start(chr_seq, sep) #get the number of bead and the bead start id for each chr
    
    start_bead_chr_1, end_bead_chr_1 = chr_bead_start[chr_1], chr_bead_start[chr_1] + num_chr_num_bead[chr_1]  #get the start bead id and the end bead id for the chr 1
    start_bead_chr_2, end_bead_chr_2 = chr_bead_start[chr_2], chr_bead_start[chr_2] + num_chr_num_bead[chr_2]  #get the start bead id and the end bead id for the chr 2

    contact_matrix = np.zeros((num_chr_num_bead[chr_1],num_chr_num_bead[chr_2]))
    for config_3D in config_3D_pop:
        
        coor_list_chr_1 = config_3D[start_bead_chr_1: end_bead_chr_1] # get the 3D coor for the chr
        coor_list_chr_1 = [i[1:] for i in coor_list_chr_1] # delete the num_chr from the coor list

        coor_list_chr_2 = config_3D[start_bead_chr_2: end_bead_chr_2] # get the 3D coor for the chr
        coor_list_chr_2 = [i[1:] for i in coor_list_chr_2] # delete the num_chr from the coor list

        distance_matrix = euclidean_distances(coor_list_chr_1, coor_list_chr_2) # compute the distances between each bead

        contact_matrix += (distance_matrix<=thresh).astype(int) #add the contact
    
    return contact_matrix

def get_contact_matrix_all_chr(chr_seq,  sep, config_3D_pop):
    """ return the contact matrix for all the chr from a population of DNA configurations"""

    num_chr_num_bead, chr_bead_start, nbead = get_num_beads_and_start(chr_seq, sep) #get the number of bead and the bead start id for each chr
    contact_matrix = np.zeros((nbead,nbead))

    for num_chr in chr_seq.keys():
        #num_chr = 'chr0' + str(chr_id)
        start_bead_chr, end_bead_chr = chr_bead_start[num_chr], chr_bead_start[num_chr] + num_chr_num_bead[num_chr] #get the start bead id and the end bead id for the chr
        contact_matrix[start_bead_chr:end_bead_chr, start_bead_chr:end_bead_chr] = np.triu(get_contact_matrix_inter_chr(chr_seq, sep, config_3D_pop, num_chr, num_chr))

    for (num_chr_1,num_chr_2) in combinations(chr_seq.keys(), r=2):
        #num_chr_1, num_chr_2 = 'chr0' + str(chr_id_1), 'chr0' + str(chr_id_2)
        start_bead_chr_1, end_bead_chr_1 = chr_bead_start[num_chr_1], chr_bead_start[num_chr_1] + num_chr_num_bead[num_chr_1]  #get the start bead id and the end bead id for the chr
        start_bead_chr_2, end_bead_chr_2 = chr_bead_start[num_chr_2], chr_bead_start[num_chr_2] + num_chr_num_bead[num_chr_2]  #get the start bead id and the end bead id for the chr
        contact_matrix[start_bead_chr_1:end_bead_chr_1, start_bead_chr_2:end_bead_chr_2] = get_contact_matrix_inter_chr(chr_seq, sep, config_3D_pop, num_chr_1, num_chr_2)
    return contact_matrix + np.transpose(np.triu(contact_matrix, k=1))
