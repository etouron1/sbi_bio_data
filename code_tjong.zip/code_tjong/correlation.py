from scipy import stats
import numpy as np


def compute_row_correlations(sim_counts, real_counts):
    correlations = np.zeros(sim_counts.shape[0]) * np.nan
    for i in range(real_counts.shape[0]):
        row_1, row_2 = sim_counts[i], real_counts[i]
        to_rm = ~(np.isnan(row_1) | np.isinf(row_1) | np.isnan(row_2) | np.isinf(row_2))
        if not np.any(to_rm):
            continue

        correlations[i] = stats.pearsonr(row_1[to_rm], row_2[to_rm])[0]
    return np.mean(correlations)


