import warnings
from glob import glob
from utils import get_expected
from iced import utils
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import euclidean_distances
import yeasts_params
import os


from scipy import stats
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("folder")
args = parser.parse_args()

folder = "results_1"

filenames = glob(os.path.join(folder, "yeast_*.txt"))
filenames.sort()
filenames = filenames

counts = None
mean_lambda = None
mean_dis = None

print("Found %d filenames" % len(filenames))
for i, filename in enumerate(filenames):
    X = np.loadtxt(filename)
    X = X[:, 1:]
    dis = euclidean_distances(X)
    if counts is None:
        counts = np.zeros((X.shape[0], X.shape[0]))
        mean_lambda = np.zeros((X.shape[0], X.shape[0]))
        mean_dis = np.zeros((X.shape[0], X.shape[0]))

    counts += dis <= 75
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        mean_lambda += dis ** - 3
    mean_dis = 1/(i+1) * (i * mean_dis + dis)

def remove_diag(counts, k=7):
    counts = counts.astype(float)
    n = counts.shape[0]
    idx = np.arange(n)

    counts[np.diag_indices_from(counts)] = np.nan
    for diag in range(1, k+1):
        counts[idx[:-diag], idx[diag:]] = np.nan
        counts[idx[diag:], idx[:-diag]] = np.nan

    return counts


counts = remove_diag(counts)
mean_lambda = remove_diag(mean_lambda)

c, l = utils.downsample_resolution(counts, yeasts_params.lengths, 3)
np.savetxt(os.path.join(folder, "counts.txt"), c)
