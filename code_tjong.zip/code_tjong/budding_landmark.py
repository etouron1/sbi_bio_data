'''Nuclear Landmark model for budding yeast'''
import argparse
import os
import numpy as np
import sys
import math
import IMP
import IMP.core
import IMP.atom
import IMP.display
import IMP.algebra
from random import random
import time
import mlxp
from create_contact_matrix import *

import os


class Chain:
    def __init__(self,list):
        self.list = list
    def get_particle(self,i):
        return self.list[i]
    
@mlxp.launch(config_path='configs')#, seeding_function=set_seed)
def main(ctx: mlxp.Context)->None:
    
    # print('cen -700, R=300, Nucleolus -1200, R=1600, tel 50 from NE')
    # outname = 'landmark_rc'
    # print('output pdb:', outname)


    # parser = argparse.ArgumentParser(description='Run volume exclusion model')
    # parser.add_argument('seed', metavar='N', type=int,
    #                     help='seed')
    # args = parser.parse_args()
    
    # # Set the seed and the random state
    # random_state = np.random.RandomState(seed=args.seed)

    # basedir = os.path.dirname(os.path.realpath(__file__))

    # outname = os.path.join(basedir, "yeast", str(args.seed),
    #                     'buddingyeast')
    # print('output pdb:', outname)
    # if os.path.exists(outname):
    #     sys.exit(0)

    
    
    # Set the seed and the random state
    random_state = np.random.RandomState(seed=ctx.config['seed'])

    
    

    #------------------------------------------------------------
    chr_seq = {"chr1": 230208, "chr2": 813136, "chr3": 316613, "chr4": 1531914,
            "chr5": 576869, "chr6": 270148, "chr7": 1090944, "chr8": 562639,
            "chr9": 439885, "chr10": 745446, "chr11": 666445, "chr12": 1078173,
            "chr13": 924430, "chr14": 784328, "chr15": 1091285, "chr16": 948060}

    # Centromers middle position
    chr_cen = {"chr1":151526, "chr2":238226, "chr3":114437, "chr4":449762,\
            "chr5":152036, "chr6":148563, "chr7":496980, "chr8":105638,\
            "chr9":355684, "chr10":436060, "chr11":439831, "chr12":150886,\
            "chr13":268086, "chr14":628812, "chr15":326643, "chr16":556010}


    chr_pdb = {"chr1":'c01 A', "chr2":'c02 B', "chr3":'c03 C', "chr4":'c04 D',\
            "chr5":'c05 E', "chr6":'c06 F', "chr7":'c07 G', "chr8":'c08 H',\
            "chr9":'c09 I', "chr10":'c10 J', "chr11":'c11 K', "chr12":'c12 L',\
            "chr13":'c13 M', "chr14":'c14 N', "chr15":'c15 O',"chr16":'c16 P'}

    chain_list=['chr1','chr2','chr3','chr4','chr5','chr6','chr7','chr8','chr9','chr10','chr11','chr12','chr13','chr14','chr15','chr16']


    t1=time.time()
    sep = 3200       # 3200 bp separation
    chr_bead = {}    # number of beads for each chromosome
    nbead = 0
    bead_start = {}  # bead label starts of a chr
    # for i in chr_seq.keys():
    #     n = chr_seq[i]/sep + 1
    #     chr_bead[i] = n
    #     nbead = nbead + n
    #     bead_start[i] = nbead - n
    for i in chr_seq.keys():
        n = int(chr_seq[i] // sep) + int(chr_seq[i] % sep!=0)
        chr_bead[i] = n # number of beads for chromosome i
        
        nbead = nbead + n # total number of beads for all chromosmes
        bead_start[i] = nbead - n # the start bead for chr i
    
    #print bead_start
    rdnaStart = bead_start['chr12'] + 140 #begin rDNA
    rdnaEnd = bead_start['chr12'] + 147 #not included as rDNA
    rdna1 = rdnaStart + 2 #last bead 1st chain
    rdna2 = rdnaStart + 3 #begin 2nd chain

    chr_order = ["chr"+str(i) for i in range(1,17)]
    startChr_pdb = [] #indexing starts from 0
    n = 0
    startChr_pdb.append(n)
    for i in range(15):
        n += chr_bead[chr_order[i]]
        startChr_pdb.append(n)

    #---------------------------------------------------------

    def bead_id(chr,gpos):
        '''Given chromosome id and genome position, returns bead id'''
        for i in range(chr_bead[chr]):
            if gpos >= i*sep and gpos < (i+1)*sep:
                beadnum = i + bead_start[chr]
                break
        return beadnum

    def find_chromosome(bid):
        """ Returns a chromosome id given a bead number"""
        for i in chr_seq.keys():
            if bid < bead_start[i] + chr_bead[i]\
            and bid >= bead_start[i]:
                chrid=i
                break
        return chrid

    def find_bead_in_chr(bid):
        """ Returns a chromosome and bead_order and mid genome position given a beadnum"""
        for i in chr_seq.keys():
            if bid < bead_start[i] + chr_bead[i]\
            and bid >= bead_start[i]:
                order = bid - bead_start[i] + 1 #order starts from 1
                genpos = order*sep - sep/2
                break
        return i,order,genpos

    def pdboutput():
            X = []
            for i in range(nbead):
                p0 = IMP.core.XYZR(chain_particles.get_particle(i))
                chr_num = list(filter(lambda k: bead_start[k] <= i, chr_seq.keys()))[-1]
                X.append([int(chr_num[3:]), p0.get_x(), p0.get_y(), p0.get_z()])
            return X

    # def pdboutput(name):
    #     pdb=[[] for i in range(nbead)]
    #     #-----------------------------
    #     cen_pos=[]
    #     for k in chr_seq.keys():
    #         j= bead_id(k,chr_cen[k])
    #         cen_pos.append(j)
    #     #------------------------------------
    #     for i in range(nbead):
    #         p0=IMP.core.XYZR(chain_particles.get_particle(i))
    #         chr=find_chromosome(i)
    #         #pdb[i].append('ATOM') 
    #         if i in cen_pos:       
    #             pdb[i].append(' CEN')  #1
    #         elif rdnaStart<=i<=rdnaEnd:
    #             pdb[i].append('rDNA') 
    #         elif i == bead_start[chr]:
    #             pdb[i].append(' L  ') 
    #         elif i == (bead_start[chr]+chr_bead[chr]-1):
    #             pdb[i].append(' R  ') 
    #         else:
    #             pdb[i].append(' O  ')
    #         #pdb[i].append('L')
    #         chr_num=list(filter(lambda k: bead_start[k]<=i, chr_seq.keys()))[-1]
    #         pdb[i].append(chr_pdb[chr_num])  #2
    #         pdb[i].append(i-bead_start[chr_num]+1) #3
    #         pdb[i].append(p0.get_x()) #4
    #         pdb[i].append(p0.get_y()) #5
    #         pdb[i].append(p0.get_z()) #6
    #         #pdb[i].append(15)
    #         pdb[i].append(chr_num)  #7
    #     ###sort the file by chromosome order
    #     sorted_pdb=[]
    #     for i in chain_list:
    #         for j in range(len(pdb)):
    #             if pdb[j][6]==i:
    #                 sorted_pdb.append(pdb[j])
    #     #insert sorted number
    #     for i in range(len(sorted_pdb)):
    #         sorted_pdb[i].insert(0,i+1)
    #     print(sorted_pdb)
    #     name=str(name)+'.pdb'
    #     #------------------------------------------------
    #     out=open(name,'w')
    #     for l in sorted_pdb:
    #         out.write("ATOM %6i %4s %5s %3i     %7.1f %7.1f %7.1f %s\n"\
    #         %(l[0],l[1],l[2],l[3],l[4],l[5],l[6],l[7]))
    #     out.close()

    # def mdstep(t,step):
    #     o = IMP.atom.MolecularDynamics()
    #     o.set_model(m)
    #     md = IMP.atom.VelocityScalingOptimizerState(xyzr,t,10)  # replace 300 K with 500 K
    #     o.add_optimizer_state(md)
    #     #print 'optimizing with temperature',t,'and',step,'steps'
    #     s=o.optimize(step)
    #     o.remove_optimizer_state(md)
    #     #print 'MD',step,'steps done @',datetime.datetime.now()
    #     return s

    def mdstep(model, constraints, xyzr, t, step):
        sf = IMP.core.RestraintsScoringFunction(constraints)
        o = IMP.atom.MolecularDynamics(model)
        #o.set_model(model)
        # replace 300 K with 500 K
        # md = IMP.atom.VelocityScalingOptimizerState(xyzr, t, 10)
        md = IMP.atom.VelocityScalingOptimizerState(model, xyzr, t)
        o.set_scoring_function(sf)
        o.add_optimizer_state(md)
        # print 'optimizing with temperature',t,'and',step,'steps'
        s = o.optimize(step)
        o.remove_optimizer_state(md)
        # print 'MD',step,'steps done @',datetime.datetime.now()
        return s

    # def cgstep(step):
    #     o = IMP.core.ConjugateGradients()
    #     o.set_model(m)
    #     f=o.optimize(step)
    #     #print 'CG',step,'steps done @',datetime.datetime.now()
    #     return f

    def cgstep(model, constraints, step=1000):
        o = IMP.core.ConjugateGradients(model)
        sf = IMP.core.RestraintsScoringFunction(constraints)
        o.set_scoring_function(sf)
        f = o.optimize(step)
        return f

    #___________________________ IMP starts _____________________________________
    #IMP.set_check_level(IMP.NONE)
    IMP.set_log_level(IMP.SILENT)
    m = IMP.Model()
    r = 15.0
    lb = 30.0 # length of bond
    kbend=0.2 
    contact_dict = {}

    xyzr = IMP.core.create_xyzr_particles(m,nbead,r)
    chain = IMP.container.ListSingletonContainer(m, xyzr)
    chain_particles = Chain(xyzr)
    # First beads
    corner1=IMP.algebra.Vector3D(-1000,-1000,-1000)
    corner2=IMP.algebra.Vector3D(1000,1000,1000)
    box=IMP.algebra.BoundingBox3D(corner1,corner2)
    rdummy=int(random()*10000)
    for i in range(rdummy):
        ranvec = IMP.algebra.get_random_vector_in(box)
    #----------------------------------------------------------  
    #print nbead
    for i in range(nbead):
        p0 = chain_particles.get_particle(i)
        IMP.atom.Mass.setup_particle(p0,1)
        p = IMP.core.XYZR(p0)
        coor = IMP.algebra.get_random_vector_in(box)
        p.set_coordinates(coor)
        #ch,b,gpos = find_bead_in_chr(i)
        #print ch,b,pdbOrder(ch,gpos)+1,i

    #sys.exit()
    #---------------------------------------------------------------------------------
    #print 'Setting up restraints'
    # Create bonds for consecutive beads in a string
    bonds = IMP.container.ListSingletonContainer(m)
    for id in chr_seq.keys():
        istart = bead_start[id]
        iend = istart + chr_bead[id]
        bp = IMP.atom.Bonded.setup_particle(chain_particles.get_particle(istart))
        for i in range(istart + 1,iend):
            if i != rdna2:
                #bp = IMP.atom.Bonded.decorate_particle(chain.get_particle(i-1))
                
                bpr = IMP.atom.Bonded.setup_particle(chain_particles.get_particle(i))
                b = IMP.atom.create_custom_bond(bp, bpr, lb, 2)
                bonds.add(b.get_particle())
                bp=bpr
            else:
                IMP.atom.Bonded.setup_particle(chain_particles.get_particle(rdna2))

    # Restraint for bonds
    bss = IMP.atom.BondSingletonScore(IMP.core.Harmonic(0,1))
    br = IMP.container.SingletonsRestraint(bss, bonds)
    #m.add_restraint(br) #0

    # Set up excluded volume
    evr = IMP.core.ExcludedVolumeRestraint(chain)
    #m.add_restraint(evr) #1


    # Set up cap
    center = IMP.algebra.Vector3D(0,0,0)
    center_nucleolus = IMP.algebra.Vector3D(-1200,0,0)
    nuclear_rad = 1000.0
    nucleolus_rad = 1600.0
    not_rDNA = IMP.container.ListSingletonContainer(m)
    for i in range(nbead):
        if i < rdnaStart or i >= rdnaEnd:
            p = chain_particles.get_particle(i)
            not_rDNA.add(p)
    ubcell = IMP.core.HarmonicUpperBound(nuclear_rad,1.0)
    sscell = IMP.core.DistanceToSingletonScore(ubcell,center)
    rcell = IMP.container.SingletonsRestraint(sscell,chain)
    #m.add_restraint(rcell) #2

    # centromers in radius 300 @-700
    centro = IMP.algebra.Vector3D(-700,0,0)
    centro_rad = 300.0
    listcentro = IMP.container.ListSingletonContainer(m)
    for k in chr_seq.keys():
        j = bead_id(k,chr_cen[k])
        pcen = chain_particles.get_particle(j)
        listcentro.add(pcen)

    ubcen = IMP.core.HarmonicUpperBound(centro_rad,1.0)
    sscen = IMP.core.DistanceToSingletonScore(ubcen,centro)
    rcentro = IMP.container.SingletonsRestraint(sscen,listcentro)
    #m.add_restraint(rcentro) #4

    constraints = [evr, br, rcell, rcentro]

    print('High temp MD..')
    mdstep(m, constraints, xyzr, 1000000, 500)
    mdstep(m, constraints, xyzr, 500000, 500)
    mdstep(m, constraints, xyzr, 300000, 500)
    mdstep(m, constraints, xyzr, 100000, 500)
    mdstep(m, constraints, xyzr, 5000, 500)
    score = cgstep(m, constraints, 1000)
    # mdstep(1000000,500)
    # mdstep(500000,500)
    # mdstep(300000,500)
    # mdstep(100000,500)
    # mdstep(5000,500)
    #score=cgstep(1000)
    print('before telo: ',score)

    # Telomeres near nuclear envelope thickness 50
    telo = IMP.container.ListSingletonContainer(m)
    #galBead =  bead_id(galpos[0],galpos[1])
    #telo.add_particle(chain.get_particle(galBead))
    for k in chr_seq.keys():
        j1 = bead_start[k]
        pt = chain_particles.get_particle(j1)
        telo.add(pt)
        j2 = j1 - 1 + chr_bead[k]
        pt = chain_particles.get_particle(j2)
        telo.add(pt)
    envelope = 950.0
    tlb = IMP.core.HarmonicLowerBound(envelope,1.0)
    sst = IMP.core.DistanceToSingletonScore(tlb,center)
    rt = IMP.container.SingletonsRestraint(sst,telo)
    #m.add_restraint(rt) #5

    constraints = constraints + [rt]

    # outside centro sphere
    #lbcen = IMP.core.HarmonicLowerBound(centro_rad,1.0)
    #sstc = IMP.core.DistanceToSingletonScore(lbcen,centro)
    #rtc = IMP.container.SingletonsRestraint(sstc,telo)
    #m.add_restraint(rtc) #6

    # rDNA chr12 near nucleolus
    rDNA = IMP.container.ListSingletonContainer(m)
    rDNA.add(chain_particles.get_particle(rdna1))
    rDNA.add(chain_particles.get_particle(rdna2))
    ub_bn2 = IMP.core.HarmonicLowerBound(nucleolus_rad,0.5)  #can also try lowerbound nucleolus_rad-rncutoff
    mindts2 = IMP.core.DistanceToSingletonScore(ub_bn2,center_nucleolus)
    nucleolir2 = IMP.container.SingletonsRestraint(mindts2,rDNA)
    #m.add_restraint(nucleolir2) #7
    constraints = constraints + [nucleolir2]

    # Set up Nucleolis #
    lbn0 = IMP.core.HarmonicUpperBound(nucleolus_rad,0.5)
    ssn0 = IMP.core.DistanceToSingletonScore(lbn0,center_nucleolus)
    rn0 = IMP.container.SingletonsRestraint(ssn0,not_rDNA)
    #m.add_restraint(rn0) #3
    constraints = constraints + [rn0]

    #-------------------

    print('High temp MD in nuc ...')
    mdstep(m, constraints, xyzr, 500000, 5000)
    mdstep(m, constraints, xyzr, 300000, 5000)
    mdstep(m, constraints, xyzr, 5000, 10000)
    score = cgstep(m, constraints, 500)

    # mdstep(500000,5000)
    # mdstep(300000,5000)
    # mdstep(5000,10000)
    #score=cgstep(500)
    print('before angle',score)

    # Angle Restraint
    angle = math.pi
    angle_set=[]
    noangle=[i for i in bead_start.values()]  #do not apply angle restraints
    noangle.append(rdna1)
    noangle.append(rdna2)
    ars = []
    for i in range(nbead-1):
        ieval = i+1
        if ieval in noangle:
            continue
        elif i in noangle:
            continue
        else:
            d1 = chain_particles.get_particle(i-1)
            d2 = chain_particles.get_particle(i)
            d3 = chain_particles.get_particle(i+1)
            pot = IMP.core.Harmonic(angle,kbend)
            ar = IMP.core.AngleRestraint(m, pot,d1,d2,d3)
            ars.append(ar)
            #m.add_restraint(ar)
            angle_set.append(ar)

    constraints_with_angle = constraints + ars 

    mdstep(m, constraints_with_angle, xyzr, 50000,500)
    mdstep(m, constraints_with_angle, xyzr, 25000,500)
    mdstep(m, constraints_with_angle, xyzr, 20000,1000)
    mdstep(m, constraints_with_angle, xyzr, 10000,1000)
    mdstep(m, constraints_with_angle, xyzr, 5000,3000)
    mdstep(m, constraints_with_angle, xyzr, 2000,5000)
    mdstep(m, constraints_with_angle, xyzr, 1000,7000)
    mdstep(m, constraints_with_angle, xyzr, 500,10000)
    score = cgstep(m, constraints_with_angle, 2500)

    # mdstep(50000,500)
    # mdstep(25000,500)
    # mdstep(20000,1000)
    # mdstep(10000,1000)
    # mdstep(5000,3000)
    # mdstep(2000,5000)
    # mdstep(1000,7000)
    # mdstep(500,10000)
    # score=cgstep(2500)

    print('angle: %.1f '%(score))
    #-----------------------
    # for i in angle_set:
    #     m.remove_restraint(i)
    score = cgstep(m, constraints, 1000)

    #score=cgstep(1000)
    #print('Final score:%.1f' %(score))
    print('Final score:', score)

    X = pdboutput()
    C = get_contact_matrix_all_chr(chr_seq,  sep, [X])
    #os.mkdir(f'{ctx.config['seed']}')
    # import pickle
    # file = open(f'{ctx.config['seed']}/DNA_config', 'wb')
    # pickle.dump(X, file)
    # file.close()
    # file = open(f'{ctx.config['seed']}/raw_contact_matrix', 'wb')
    # pickle.dump(C, file)
    # file.close()
    ctx.logger.log_artifacts(X, artifact_name='DNA_config', artifact_type='pickle')
    ctx.logger.log_artifacts(C, artifact_name='raw_contact_matrix', artifact_type='pickle')
    #-------------------------

    #mdstep(1000,1000)
    #score=cgstep(1000)
    #print '\nFinal score with remove angle restraint is: ',score

    #name='final_without_angle'
    #output(chain,nbead,name)
    t2=time.time()

    print('time spend is ', t2-t1, ' s')


main()