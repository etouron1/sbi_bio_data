#!/bin/bash
#OAR -n data/71
#OAR -E /home/etouron/SBI_bio/data/71/log.stderr
#OAR -O /home/etouron/SBI_bio/data/71/log.stdout
#OAR -l nodes=1/core=8, walltime=15:00:00
#OAR -p cluster='thoth'
#OAR -t besteffort
#OAR -t idempotent
source ~/.bash_profile
cd /home/etouron/SBI_bio
/services/scratch/mistis/etouron/miniconda3/envs/sbi_bio/bin/python main.py job_id=21             +mlxp.logger.forced_log_id=71            +mlxp.logger.parent_log_dir=/home/etouron/SBI_bio/data             +mlxp.use_scheduler=False            +mlxp.use_version_manager=False            +mlxp.interactive_mode=False
