import torch
from torch.nn import functional
import time
import os

from utils import assign_device, get_dtype, instantiate
from omegaconf import OmegaConf

import pprint
from contextlib import nullcontext
pp = pprint.PrettyPrinter(indent=4)

from contact_matrix import get_contact_matrix_all_chr



class Trainer:
    """
    """
    def __init__(self,config,logger):
        """
        Initializes the Trainer class with the provided configuration and logger.

        Parameters:
        - config (object): Configuration object containing various settings.
        - logger (object): Logger object for logging metrics and information.
        """

        self.logger = logger
        self.args = config
        self.device = assign_device(self.args.system.device)
        self.dtype = get_dtype(self.args.system.dtype)
        self.round = 1
        #self.build_trainer() 

        #self.epochs = {'upstream':0,'downstream':0}
        #self.acc_test_best = 0.0


    def build_trainer(self):
        """
        Builds the trainer by setting up data, models, and optimization components (losses, optimizers).
        """

        self.simulator = instantiate(self.args.simulator.name)(self.args.simulator.args)

    def simulate(self):
        
        self.simulator = instantiate(self.args.simulator.name)(self.args.simulator.args)#init the simulator
        start_time = time.time()
        X = self.simulator.sample() # liste des chr de lg nb_total_beads avec par chr nb_chr_beads quadruplets : ex [14, x, y, z] pour le 1er bead du chr 14
        end_time = time.time()
        print("total time: "+ str((end_time-start_time)))
        C = get_contact_matrix_all_chr('y', self.args.simulator.args.sep, [X])
        return X, C
        

        # self.logger.log_artifacts(X, artifact_name='DNA_config', artifact_type='pickle')
        # self.logger.log_artifacts(C, artifact_name='raw_contact_matrix', artifact_type='pickle')
    
    def simulate_n_times(self):
        try :
            start_round = self.logger.load_artifacts(artifact_name='next_start_round', artifact_type='pickle')
            print(f"Load checkpoint, starting from round {start_round}")
        except:
            start_round=1
            print(f"Failed to load checkpoint, starting from round {start_round}")

        
        for i in range(start_round,self.args.n_simu+1):
            print(f"simulation {i} / {self.args.n_simu}")
            if i==1:
                X, C = self.simulate()
            else:
                C = self.logger.load_artifacts(artifact_name='tmp_contact_matrix', artifact_type='pickle')
                X, C_tmp = self.simulate()
                C += C_tmp
            self.logger.log_artifacts(C, artifact_name='tmp_contact_matrix', artifact_type='pickle')
            self.logger.log_artifacts(i+1, artifact_name='next_start_round', artifact_type='pickle')

        self.logger.log_artifacts(X, artifact_name='DNA_config', artifact_type='pickle')
        self.logger.log_artifacts(C, artifact_name='raw_contact_matrix', artifact_type='pickle')

        print("Removing temporary files (contact matrix and start id)")
        os.remove(f"data/{self.logger.log_id}/artifacts/pickle/next_start_round")
        os.remove(f"data/{self.logger.log_id}/artifacts/pickle/tmp_contact_matrix")
        print("Successfull simulation")




        




