import os
import sys
import math
import IMP
import IMP.core
import IMP.atom
import IMP.display
import IMP.algebra
import numpy as np
import time



chr_seq = {'chr01': 240000, 'chr02': 820000, 'chr03': 320000, 'chr04': 1540000, 
                 'chr05': 580000, 'chr06': 280000, 'chr07': 1100000, 'chr08': 570000, 
                 'chr09': 440000, 'chr010': 750000, 'chr011': 670000, 'chr012': 1080000, 
                 'chr013': 930000, 'chr014': 790000, 'chr015': 1100000, 'chr016': 950000}

chr_cen = {'chr01': 151584, 'chr02': 238325, 'chr03': 114499, 'chr04': 449819, 
                 'chr05': 152103, 'chr06': 148622, 'chr07': 497042, 'chr08': 105698, 
                 'chr09': 355742, 'chr010': 436418, 'chr011': 439889, 'chr012': 150946, 
                 'chr013': 268149, 'chr014': 628877, 'chr015': 326703, 'chr016': 556070}

sep = 3200




# def get_num_beads_and_start(chr_seq, sep):
#     chr_bead = {}    # number of beads for each chromosome
#     nbead = 0
#     bead_start = {}  # bead label starts of a chr

#     for i in sorted(chr_seq.keys()):
#         n = int(chr_seq[i] / sep) + 1
#         chr_bead[i] = n
#         nbead = nbead + n
#         bead_start[i] = nbead - n
#     return chr_bead, bead_start, nbead

def get_num_beads_and_start(chr_seq, sep):

    """ return a dict {chr : nb of beads}, a dict {chr : number of the start bead}, the total number of beads for all chr"""

    chr_bead = {}    # number of beads for each chromosome
    nbead = 0		# total number of beads for all chromosomes
    bead_start = {}  # bead label starts of a chr

    for i in chr_seq.keys(): # attention sorted()
        n = int(chr_seq[i] // sep) + int(chr_seq[i] % sep!=0)
        chr_bead[i] = n # number of beads for chromosome i
        
        nbead = nbead + n # total number of beads for all chromosmes
        bead_start[i] = nbead - n # the start bead for chr i
    return chr_bead, bead_start, nbead


def mdstep(model, constraints, xyzr, t, step):
    sf = IMP.core.RestraintsScoringFunction(constraints)
    o = IMP.atom.MolecularDynamics(model)
    # replace 300 K with 500 K
    # md = IMP.atom.VelocityScalingOptimizerState(xyzr, t, 10)
    md = IMP.atom.VelocityScalingOptimizerState(model, xyzr, t)
    o.set_scoring_function(sf)
    o.add_optimizer_state(md)
    # print 'optimizing with temperature',t,'and',step,'steps'
    s = o.optimize(step)
    o.remove_optimizer_state(md)
    # print 'MD',step,'steps done @',datetime.datetime.now()
    return s


def cgstep(model, constraints, step=1000):
    o = IMP.core.ConjugateGradients(model)
    sf = IMP.core.RestraintsScoringFunction(constraints)
    o.set_scoring_function(sf)
    f = o.optimize(step)
    return f


class Chain:
    def __init__(self,list):
        self.list = list
    def get_particle(self,i):
        return self.list[i]


class VRSM_Simulator:
    def __init__(self,args):
        self.args = args
        self.nuclear_rad = args.nuclear_rad # 850
        self.centro_rad = args.centro_rad
        self.telo_thick = args.telo_thick # 50 nm envelope thickness for telomere (nl)
        self.sep = args.sep # 3200
        self.chr_bead,self.bead_start, self.nbead = get_num_beads_and_start(chr_seq,self.sep)
        self.r = args.radius
        self.lb = args.lb  # length of bond
        self.kbend = args.kbend
        self.random_state = np.random.RandomState(seed=args.seed)
        self.num_rand = args.num_rand
        self.build_IMP()

    def bead_id(self, chr, gpos):
        '''Given chromosome id and genome position, returns bead id'''
        
        for i in range(self.chr_bead[chr]):
            if gpos >= i*self.sep and gpos < (i+1)*self.sep:
                beadnum = i + self.bead_start[chr]
                break
        return beadnum
    # def find_chromosome(self, bid):
    #     """ Returns a chromosome id given a bead number"""
    #     for i in sorted(chr_seq.keys()):
    #         if bid < self.bead_start[i] + self.chr_bead[i] \
    #            and bid >= self.bead_start[i]:
    #             chrid = i
    #             break
    #     return chrid


    # def find_bead_in_chr(self, bid):
    #     """
    #     Returns a chromosome and bead_order and mid genome position given a
    #     beadnum
    #     """
    #     for i in sorted(chr_seq.keys()):
    #         if bid < self.bead_start[i] + self.chr_bead[i] \
    #            and bid >= self.bead_start[i]:
    #             order = bid - self.bead_start[i] + 1  # order starts from 1
    #             genpos = order * self.sep - self.sep / 2
    #             break
    #     return i, order, genpos

    def build_IMP(self):
        IMP.set_log_level(IMP.SILENT)
        m = IMP.Model()
        print(self.nbead)
        print(m)
        print(self.r)
        self.xyzr = IMP.core.create_xyzr_particles(m, self.nbead, self.r)
        chain = IMP.container.ListSingletonContainer(m, self.xyzr)
        self.chain = Chain(self.xyzr)

        corner1 = IMP.algebra.Vector3D(-self.nuclear_rad, 
                                       -self.nuclear_rad, 
                                       -self.nuclear_rad)
        corner2 = IMP.algebra.Vector3D(self.nuclear_rad, 
                                       self.nuclear_rad, 
                                       self.nuclear_rad)
        box = IMP.algebra.BoundingBox3D(corner1, corner2)
        rdummy = int(self.random_state.rand() * self.num_rand)
        for i in range(rdummy):
            ranvec = IMP.algebra.get_random_vector_in(box)
        # ----------------------------------------------------------
        # print nbead
        for i in range(self.nbead):
            p0 = self.chain.get_particle(i)
            IMP.atom.Mass.setup_particle(p0, 1)
            p = IMP.core.XYZR(p0)
            coor = IMP.algebra.get_random_vector_in(box)
            p.set_coordinates(coor)
            p.set_coordinates_are_optimized(True)
        # Create bonds for consecutive beads in a string
        bonds = IMP.container.ListSingletonContainer(m)
        for id in sorted(chr_seq.keys()):
            istart = self.bead_start[id]
            iend = istart + self.chr_bead[id]
            bp = IMP.atom.Bonded.setup_particle(self.chain.get_particle(istart))
            for i in range(istart + 1, iend):
                bpr = IMP.atom.Bonded.setup_particle(self.chain.get_particle(i))
                b = IMP.atom.create_custom_bond(bp, bpr, self.lb, 2)
                bonds.add(b.get_particle())
                bp = bpr

        # Restraint for bonds
        bss = IMP.atom.BondSingletonScore(IMP.core.Harmonic(0, 1))
        br = IMP.container.SingletonsRestraint(bss, bonds)
        # m.add_restraint(br)  # 0

        # Set up excluded volume
        evr = IMP.core.ExcludedVolumeRestraint(chain)
        # m.add_restraint(evr)  # 1


        sf = IMP.core.RestraintsScoringFunction([evr, br])
        bd = IMP.atom.MolecularDynamics(m)
        md = IMP.atom.VelocityScalingOptimizerState(m, self.xyzr, 10)
        o = IMP.core.ConjugateGradients(m)
        o.set_scoring_function(sf)
        # Set up cap
        self.center = IMP.algebra.Vector3D(0, 0, 0)
        ubcell = IMP.core.HarmonicUpperBound(self.nuclear_rad, 1.0)
        sscell = IMP.core.DistanceToSingletonScore(ubcell, self.center)
        rcell = IMP.container.SingletonsRestraint(sscell, chain)
        # m.add_restraint(rcell)  # 2

        # centromers in radius 300 @-700
        
        centro = IMP.algebra.Vector3D(self.nuclear_rad - self.centro_rad, 0, 0)
        listcentro = IMP.container.ListSingletonContainer(m)
        for k in sorted(chr_seq.keys()):
            j = self.bead_id(k, chr_cen[k])
            pcen = self.chain.get_particle(j)
            listcentro.add(pcen)

        ubcen = IMP.core.HarmonicUpperBound(self.centro_rad, 1.0)
        sscen = IMP.core.DistanceToSingletonScore(ubcen, centro)
        rcentro = IMP.container.SingletonsRestraint(sscen, listcentro)
        #m.add_restraint(rcentro)  # 4

        self.constraints = [evr, br, rcell, rcentro]
        self.m = m 
    def simulate_before_telo(self):
        mdstep(self.m, self.constraints, self.xyzr, 1000000, 500)
        mdstep(self.m, self.constraints, self.xyzr, 500000, 500)
        mdstep(self.m, self.constraints, self.xyzr, 300000, 500)
        mdstep(self.m, self.constraints, self.xyzr, 100000, 500)
        mdstep(self.m, self.constraints, self.xyzr, 5000, 500)
        score = cgstep(self.m, self.constraints, 1000)
        print('before telo: ', score)

    def simulate_before_angle(self):
        # Telomeres near nuclear envelope thickness 50
        telo = IMP.container.ListSingletonContainer(self.m)
        for k in sorted(chr_seq.keys()):
            j1 = self.bead_start[k]
            pt = self.chain.get_particle(j1)
            telo.add(pt)
            j2 = j1 - 1 + self.chr_bead[k]
            pt = self.chain.get_particle(j2)
            telo.add(pt)
        envelope = self.nuclear_rad - self.telo_thick
        tlb = IMP.core.HarmonicLowerBound(envelope, 1.0)
        sst = IMP.core.DistanceToSingletonScore(tlb, self.center)
        rt = IMP.container.SingletonsRestraint(sst, telo)
        #m.add_restraint(rt)  # 5

        self.constraints = self.constraints + [rt]
        mdstep(self.m, self.constraints, self.xyzr, 500000, 5000)
        mdstep(self.m, self.constraints, self.xyzr, 300000, 5000)
        mdstep(self.m, self.constraints, self.xyzr, 5000, 10000)
        score = cgstep(self.m, self.constraints, 500)
        print('before angle', score)

    def simulate_high_temp(self):
        # Angle Restraint
        angle = math.pi
        angle_set = []
        noangle = [i for i in self.bead_start.values()]  # do not apply angle restraints
        ars = []
        for i in range(self.nbead - 1):
            ieval = i + 1
            if ieval in noangle:
                continue
            elif i in noangle:
                continue
            else:
                d1 = self.chain.get_particle(i - 1)
                d2 = self.chain.get_particle(i)
                d3 = self.chain.get_particle(i + 1)
                pot = IMP.core.Harmonic(angle, self.kbend)
                ar = IMP.core.AngleRestraint(self.m, pot, d1, d2, d3)
                ars.append(ar)
                angle_set.append(ar)


        constraints = self.constraints + ars 
        mdstep(self.m, constraints, self.xyzr, 500000, 5000)
        mdstep(self.m, constraints, self.xyzr, 300000, 5000)
        mdstep(self.m, constraints, self.xyzr, 5000, 10000)
        score = cgstep(self.m, constraints, 500)
        score = cgstep(self.m, self.constraints, 1000)
        print('Final score:', score)		


    def pdboutput(self):
        X = []
        for i in range(self.nbead):
            p0 = IMP.core.XYZR(self.chain.get_particle(i))
            chr_num = list(filter(lambda k: self.bead_start[k] <= i, chr_seq.keys()))[-1]
            X.append([int(chr_num[3:]), p0.get_x(), p0.get_y(), p0.get_z()])
        return X

    def sample(self):
        self.simulate_before_telo()
        self.simulate_before_angle()
        self.simulate_high_temp()
        return self.pdboutput()

