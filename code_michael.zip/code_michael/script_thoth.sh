#!/bin/bash

#OAR -l nodes=1/core=8, walltime=40:00:00

#OAR -p cluster='thoth'

#OAR -t besteffort 

#OAR -t idempotent

source ~/.bash_profile
#python main.py +mlxp.logger.forced_log_id=128,129,130,136
python main.py job_id=1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25





