import time
import mlxp
from trainer import Trainer
from utils import set_seed 


@mlxp.launch(config_path='configs')#, seeding_function=set_seed)
def generate(ctx: mlxp.Context)->None:
    training = Trainer(ctx.config, ctx.logger)
    #instantiate the simulator
    # try:
        
    #     ckpt  = ctx.logger.load_artifacts(artifact_name='last_ckpt') 
    #     training.epochs = ckpt['epoch']
    #     training.method = ckpt['method'] 
    #     print("Loading from latest checkpoint")
     
    # except:
    #     print("Failed to load checkpoint, Starting from scratch")

    #training.simulate()
    training.simulate_n_times()


if __name__ == "__main__":
    
    generate()
