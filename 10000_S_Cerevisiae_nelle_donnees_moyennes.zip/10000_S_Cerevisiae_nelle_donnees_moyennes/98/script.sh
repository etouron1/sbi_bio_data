#!/bin/bash
#OAR -n debug/98
#OAR -E /home/etouron/SBI_bio/data/outputs/debug/98/log.stderr
#OAR -O /home/etouron/SBI_bio/data/outputs/debug/98/log.stdout
#OAR -l gpudevice=1/core=10, walltime=50:00:00
#OAR -p cluster='thoth'
#OAR -t besteffort
#OAR -t idempotent
source ~/.bash_profile
cd /home/etouron/SBI_bio
/services/scratch/mistis/etouron/miniconda3/envs/sbi_bio/bin/python main.py job_id=38             +mlxp.logger.forced_log_id=98            +mlxp.logger.parent_log_dir=/home/etouron/SBI_bio/data/outputs/debug             +mlxp.use_scheduler=False            +mlxp.use_version_manager=False            +mlxp.interactive_mode=False
